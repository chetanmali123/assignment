<?php

class Test{
	function abc()
		{
		echo "simple test function";
		}
	}