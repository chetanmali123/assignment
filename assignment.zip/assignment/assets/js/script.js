
			function myFunction()
			{document.getElementById("image").src="images/bulon.jpg";
			document.getElementById("image").src="images/buloff.jpg";
}
			window.alert('error')
			
			
			/*function myFunction()
			{document.getElementById('d').innerHTML=
			typeof "chetan" +"<br>"+
			typeof 321 +"<br>"+
			typeof false + "<br>"+
			typeof [3,2,3] +"<br>"+}*/
			
			