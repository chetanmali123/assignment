<html>
<head>
<title>Assignment</title>
 
 <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
 <link href="<?php echo base_url('assets/css/bootstrapValidator.css')?>" rel="stylesheet">
 <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #description {
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
      }

      #infowindow-content .title {
        font-weight: bold;
      }

      #infowindow-content {
        display: none;
      }

      #map #infowindow-content {
        display: inline;
      }

      .pac-card {
        margin: 10px 10px 0 0;
        border-radius: 2px 0 0 2px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        outline: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        background-color: #fff;
        font-family: Roboto;
      }

      #pac-container {
        padding-bottom: 12px;
        margin-right: 12px;
      }

      .pac-controls {
        display: inline-block;
        padding: 5px 11px;
      }

      .pac-controls label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }

      #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 400px;
      }

      #pac-input:focus {
        border-color: #4d90fe;
      }

      #title {
        color: #fff;
        background-color: #4d90fe;
        font-size: 25px;
        font-weight: 500;
        padding: 6px 12px;
      }
      #target {
        width: 345px;
      }
    </style>
</head>
<body>
	
	
	
	<div class="container">
		<?php if(count($record) > 0): ?>
			<?php echo form_open("Admin/edit_record",['id'=>'add_form'])?>
				<?php 
				foreach($record as $records)
				{
					
				}
				?>
				<div class="row">
					<center><h3>Edit Sample Assignment</h3></center>
					<hr/>
					<div class="col-md-5 col-md-offset-1">
						<div class="form-group">
							TODO:
							<input type="text" value="<?php echo $records->todo;?>" name="todo" class="form-control" required/>
						</div>
						<div class="form-group">
							Month:
							<select name="month" class="form-control" required >
								<option value="" selected>Select</option>
								<option value="January" <?php if($records->month == 'January'): echo "selected"; endif;?>>January</option>
								<option value="February" <?php if($records->month == 'February'): echo "selected"; endif;?>>February</option>
								<option value="March" <?php if($records->month == 'March'): echo "selected"; endif;?>>March</option>
								<option value="April" <?php if($records->month == 'April'): echo "selected"; endif;?>>April</option>
								<option value="May" <?php if($records->month == 'May'): echo "selected"; endif;?>>May</option>
								<option value="June" <?php if($records->month == 'June'): echo "selected"; endif;?>>June</option>
								<option value="July" <?php if($records->month == 'July'): echo "selected"; endif;?>>July</option>
								<option value="August" <?php if($records->month == 'August'): echo "selected"; endif;?>>August</option>
								<option value="September" <?php if($records->month == 'September'): echo "selected"; endif;?>>September</option>
								<option value="October" <?php if($records->month == 'October'): echo "selected"; endif;?>>October</option>
								<option value="November" <?php if($records->month == 'November'): echo "selected"; endif;?>>November</option>
								<option value="December" <?php if($records->month == 'December'): echo "selected"; endif;?>>December</option>
							</select>
						</div>
					</div>
					<div class="col-md-5">
						<div class="form-group">
							City:
							<select name="city" class="form-control" required >
								<option value="" selected>Select</option>
								<?php
								foreach($city as $citys)
								{
									if($citys->id == $records->city):
										?>
										<option value="<?php echo $citys->id;?>" selected><?php echo $citys->city;?></option>
										<?php
									else:
										?>
										<option value="<?php echo $citys->id;?>"><?php echo $citys->city;?></option>
										<?php
									endif;
								}
								?>
							</select>
						</div>
						<div class="form-group">
							Time:
							<input type="time" value="<?php if($records->time != '00:00:00'): echo $records->time; endif;?>" name="time" class="form-control"/>
						</div>
					</div>
				</div>
				<hr/>
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<?php echo form_hidden('p',base64_encode($records->id * 155));?>
						<input type="submit" class="form-control btn btn-primary" value="Submit"/>
					</div>
				</div>
			</form>
		<?php else: ?>
			<?php echo form_open("Admin/add_record",['id'=>'add_form'])?>
				<div class="row">
					<center><h3>Sample Assignment</h3></center>
					<hr/>
					<div class="col-md-5 col-md-offset-1">
						<div class="form-group">
							TODO:
							<input type="text" name="todo" class="form-control" required/>
						</div>
						<div class="form-group">
							Month:
							<select name="month" class="form-control" required >
								<option value="" selected>Select</option>
								<option value="January">January</option>
								<option value="February">February</option>
								<option value="March">March</option>
								<option value="April">April</option>
								<option value="May">May</option>
								<option value="June">June</option>
								<option value="July">July</option>
								<option value="August">August</option>
								<option value="September">September</option>
								<option value="October">October</option>
								<option value="November">November</option>
								<option value="December">December</option>
							</select>
						</div>
					</div>
					<div class="col-md-5">
						<div class="form-group">
							City:
							<select name="city" class="form-control" required >
								<option value="" selected>Select</option>
								<?php
								foreach($city as $citys)
								{
									?>
									<option value="<?php echo $citys->id;?>"><?php echo $citys->city;?></option>
									<?php
								}
								?>
							</select>
						</div>
						<div class="form-group">
							Time:
							<input type="time" name="time" class="form-control"/>
						</div>
					</div>
				</div>
				<hr/>
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<input type="submit" class="form-control btn btn-primary" value="Submit"/>
					</div>
				</div>
			</form>
		</div>
		
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBQtMlYO-SV5UTtNS0RwBJs6hBKhDqmLOM&libraries=places&callback=initAutocomplete"
			 async defer></script>
		<input id="pac-input" class="controls" type="text" placeholder="Search Box">
		<div class="container">
			<div id="map"></div>
		</div>
	<?php endif; ?>
    
</body>
<script src="<?php echo base_url('assets/js/jquery.js')?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/bootstrapValidator.js')?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php if($this->session->flashdata("success")):?>
		<script>
			swal({
				text: "<?php echo $this->session->flashdata('success'); ?>",
				icon: "success",
				button: "Okay!",
			});
		</script>
		<?php elseif($this->session->flashdata("warning")):?>
		<script>
			swal({
				text: "<?php echo $this->session->flashdata('warning'); ?>",
				icon: "warning",
				button: "Okay!",
			});
		</script>
	<?php endif;?>
<script>
	$(document).ready(function() {
    $('#add_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
           /*  valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh' */
        },
			submitHandler: function(validator, form, submitButton) {
         	  // Do nothing
         	},
        fields: {
            }
        })
}); 

</script>
	<script>
      // This example adds a search box to a map, using the Google Place Autocomplete
      // feature. People can enter geographical searches. The search box will return a
      // pick list containing a mix of places and predicted search terms.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      
      function initAutocomplete() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -33.8688, lng: 151.2195},
          zoom: 13,
          mapTypeId: 'roadmap'
        });

        // Create the search box and link it to the UI element.
        var input = document.getElementById('pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
        map.addListener('bounds_changed', function() {
          searchBox.setBounds(map.getBounds());
        });

        var markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
        searchBox.addListener('places_changed', function() {
          var places = searchBox.getPlaces();

          if (places.length == 0) {
            return;
          }

          // Clear out the old markers.
          markers.forEach(function(marker) {
            marker.setMap(null);
          });
          markers = [];

          // For each place, get the icon, name and location.
          var bounds = new google.maps.LatLngBounds();
          places.forEach(function(place) {
            if (!place.geometry) {
              console.log("Returned place contains no geometry");
              return;
            }
            var icon = {
              url: place.icon,
              size: new google.maps.Size(71, 71),
              origin: new google.maps.Point(0, 0),
              anchor: new google.maps.Point(17, 34),
              scaledSize: new google.maps.Size(25, 25)
            };

            // Create a marker for each place.
            markers.push(new google.maps.Marker({
              map: map,
              icon: icon,
              title: place.name,
              position: place.geometry.location
            }));

            if (place.geometry.viewport) {
              // Only geocodes have viewport.
              bounds.union(place.geometry.viewport);
            } else {
              bounds.extend(place.geometry.location);
            }
          });
          map.fitBounds(bounds);
        });
      }

   </script>
</html>