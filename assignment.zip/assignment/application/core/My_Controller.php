<?php

class My_Controller extends CI_Controller{
	
	public function _construct()
	{
		if(! $this->isAuthorise())
			return redirect('home');
	}
}