 
<?php
class Assignment extends CI_Model{

	public function get_record()
	{
		$q = $this->db->select('*')
						->get('assignment');
		
		return $q->result();

	}
	public function get_city()
	{
		$q = $this->db->select('*')
						->get('city');
		
		return $q->result();
	}
	public function add_record($data)
	{
		$q = $this->db->insert('assignment',$data);
		return 1;
	}
	public function edit_record($record_id,$data)
	{
		$q = $this->db->where('id',$record_id)
						->update('assignment',$data);
		return 1;
	}
}

?>