<?php 

function test()
{
echo "welcome";
}
