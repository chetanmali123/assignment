<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller{
	function __construct()
	{
		parent:: __construct();
		$this->load->library('encryption');
		$this->load->model("Assignment");
	}
	
	public function index()
	{
		$data =  $this->Assignment->get_city();
		$data1 =  $this->Assignment->get_record();
		$this->load->view('assignment',['record'=>$data1,'city'=>$data]);
	}
	
	public function add_record()
	{
		date_default_timezone_set('Asia/Calcutta');
		$date=date('Y-m-d');
		$time=date('H:i:s');
		$dt="$date $time";
		
		$todo=ucfirst($this->input->post("todo"));
		$month=$this->input->post("month");
		$city=$this->input->post("city");
		$time=$this->input->post("time");
		
		
		if(empty($todo))
		{
			$this->session->set_flashdata('warning','Please enter todo field.');
			return redirect('Admin');
		}
		if(empty($month))
		{
			$this->session->set_flashdata('warning','Please enter month field.');
			return redirect('Admin');
		}
		if(empty($city))
		{
			$this->session->set_flashdata('warning','Please enter city field.');
			return redirect('Admin');
		}
		if(empty($time))
		{
			$time = '00:00:00';
		}
		$data=array(
			'todo'			=>$todo,
			'month'			=>$month,
			'city'			=>$city,
			'time'			=>$time,
			'dt'			=>$dt
			);
		
		$res=$this->Assignment->add_record($data);
		if($res==1)
		{
			$this->session->set_flashdata('success','Record added successfully.');
			return redirect('Admin');
		}
	}
	public function edit_record()
	{
		$record_id=base64_decode($this->input->post("p")); 
		$record_id = $record_id / 155; 
		$todo=$this->input->post("todo");
		$month=$this->input->post("month");
		$city=$this->input->post("city");
		$time=$this->input->post("time");
		
		if(empty($todo))
		{
			$this->session->set_flashdata('warning','Please enter todo field.');
			return redirect('Admin');
		}
		if(empty($month))
		{
			$this->session->set_flashdata('warning','Please enter month field.');
			return redirect('Admin');
		}
		if(empty($city))
		{
			$this->session->set_flashdata('warning','Please enter city field.');
			return redirect('Admin');
		}
		if(empty($time))
		{
			$time = '00:00:00';
		}
		$data=array(
			'todo'			=>$todo,
			'month'			=>$month,
			'city'			=>$city,
			'time'			=>$time,
			'dt'			=>$dt
			);
		
		$res=$this->Assignment->edit_record($record_id,$data);
		if($res==1)
		{
			$this->session->set_flashdata('success','Record updated successfully.');
			return redirect('Admin');
		}
	}
}


?>