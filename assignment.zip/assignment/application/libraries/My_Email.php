<?php  

class My_Email extends CI_Email{
    
	public function test()
	{
	echo "Test function for email";
	}
}